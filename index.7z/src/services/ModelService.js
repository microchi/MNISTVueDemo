import * as tf from '@tensorflow/tfjs';

const IMAGE_H = 28; // 圖片高
const IMAGE_W = 28; // 圖片寬

export default class ModelService {
  // 建立全連結模型
  static CreateDenseModel() {
    const model = tf.sequential(); // 建立序列模型
    model.add(tf.layers.flatten({ inputShape: [IMAGE_H, IMAGE_W, 1] })); // 降維(攤平)成一維 (輸入層)

    model.add(tf.layers.dense({ units: 42, activation: 'relu', kernelInitializer: 'varianceScaling' })); // 42 點 全連結 層 (隱藏層) relu(線性激活函數)

    model.add(tf.layers.dense({ units: 10, activation: 'softmax', kernelInitializer: 'varianceScaling' })); // 10 點 全連結 層 (輸出層) softmax(正規化激活函數, 輸出值為0~1幾率)

    return model;
  }

  // 建立卷積模型
  static CreateConvModel() {
    const model = tf.sequential(); // 建立序列模型

    model.add(
      tf.layers.conv2d({
        inputShape: [IMAGE_H, IMAGE_W, 1], // 輸入圖片大小 (輸入層)
        kernelSize: 3, // 3x3 卷積核
        filters: 16, // 16 個卷積濾鏡
        activation: 'relu', // 線性激活函數
        kernelInitializer: 'varianceScaling', // 初始化標準差為方差縮放
      })
    );

    model.add(tf.layers.maxPooling2d({ poolSize: 2, strides: 2 })); // 區域最大值取樣 池化核大小 2x2 步長 2

    model.add(tf.layers.conv2d({ kernelSize: 3, filters: 32, activation: 'relu', kernelInitializer: 'varianceScaling' })); // 卷積濾鏡 32 個

    model.add(tf.layers.conv2d({ kernelSize: 3, filters: 64, activation: 'relu', kernelInitializer: 'varianceScaling' })); // 卷積濾鏡 64 個

    model.add(tf.layers.maxPooling2d({ poolSize: 2, strides: 2 })); // 區域最大值取樣

    model.add(tf.layers.batchNormalization());

    model.add(tf.layers.conv2d({ kernelSize: 3, filters: 128, activation: 'relu', kernelInitializer: 'varianceScaling' })); // 卷積濾鏡 128 個

    model.add(tf.layers.maxPooling2d({ poolSize: 2, strides: 2 })); // 區域最大值取樣

    model.add(tf.layers.batchNormalization());

    model.add(tf.layers.flatten()); // 降維(攤平)

    model.add(tf.layers.dense({ units: 64, activation: 'relu', kernelInitializer: 'varianceScaling' })); // 全連結層 64 個

    model.add(tf.layers.dropout({ rate: 0.8 })); // 隨機選擇 80% 輸入層

    model.add(tf.layers.dense({ units: 64, activation: 'relu', kernelInitializer: 'varianceScaling' })); // 全連結層 64 個

    model.add(tf.layers.dropout({ rate: 0.8 })); // 隨機選擇 80% 輸入層

    model.add(tf.layers.dense({ units: 10, activation: 'softmax', kernelInitializer: 'varianceScaling' })); // 10 點 全連結 層 (輸出層) softmax(正規化激活函數, 輸出值為0~1幾率)

    return model;
  }
}
